Cufon.replace('.site-nav li', { fontFamily: 'Myriad Pro Regular', hover:true });
Cufon.replace('h2, h3', { fontFamily: 'Myriad Pro Regular' });
Cufon.replace('h2 b, h2 strong', { fontFamily: 'Myriad Pro Bold' });
Cufon.replace('.box h3', { fontFamily: 'Myriad Pro Regular', textShadow:'1px 1px #aee5ef' });
Cufon.replace('.form-box h3', { fontFamily: 'Myriad Pro Regular', textShadow:'1px 1px #e02323' });